<?php
    $pdo = new PDO("mysql:dbname=projeto2info1;host=localhost","root","");//para conexão com banco de dados
?>