#include <stdio.h>
#include <stdlib.h>

int main()
{
    float nota1 = 7.0
    , nota2 = 8.0
    , nota3 = 6.5
    , prova = 5.4
    , mediafinal;

    char aluno[10] = "Fulano";

    printf("Aluno: %s\nNotas das Tarefas: %.1f, %.1f, %.1f\nNota da Prova: %.1f\n", aluno, nota1, nota2, nota3, prova);

    mediafinal = ((nota1+nota2+nota3)/3)*0.4+prova*0.6;

    printf("Media final: %.1f\n", mediafinal);

    if(mediafinal >= 7){
        printf("RESULTADO: Aprovado");
    }else{
        printf("RESULTADO: Reprovado");
    }



    return 0;
}
