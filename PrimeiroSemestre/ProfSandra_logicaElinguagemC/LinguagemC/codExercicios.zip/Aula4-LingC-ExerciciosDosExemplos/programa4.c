#include <stdio.h>
#include <locale.h>

//Fa�a um algoritmo que leia o pre�o de um par de sapatos numa loja, e escreva
//o pre�o com desconto de X%.

int main() {
	setlocale(LC_ALL,"portuguese");
	
	float preco, desc, valorFinal, valorDesc;
	
	printf("Informe valor do par de sapatos: ");
	scanf("%f",&preco);
	
	printf("Informe o percentual do desconto do produto: ");
	scanf("%f",&desc);
	
	//valorDesc = (preco * desc);

	valorFinal = (preco - (preco * desc)/100);
	
	//printf("\nValor do desconto de 10%% � %2.2f",valorDesc);
	printf("\n\nPre�o final ser� R$ %.2f",valorFinal);
	
	
	return 0;
}
