#include <stdio.h>
#include <locale.h>
#include <string.h>

//Escreva um algoritmo que leia o nome e a qualidade de uma pessoa, e exiba a
//mensagem "<nome>" � uma pessoa que tem "<qualidade>".
int main() {
	setlocale(LC_ALL,"portuguese");
	
	char nome[50];
	char qualidade[15];
	
	printf("Informe seu nome: ");
	gets(nome);
	
	printf("Informe sua qualidade: ");
	gets(qualidade);
	
	printf("%s � uma pessoa que tem %s ",nome,qualidade);
	
	return 0;
}
