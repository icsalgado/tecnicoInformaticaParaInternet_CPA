#include <stdio.h>
#include <locale.h>
//Fa�a um algoritmo para exibir a multiplica��o de dois n�meros inteiros
//fornecidos pelo usu�rio.
int main() {
	setlocale(LC_ALL,"portuguese");
	
	int n1, n2, mult;
	
	printf("Informe primeiro valor inteiro: ");
	scanf("%d",&n1);
	
	printf("Informe segundo valor inteiro: ");
	scanf("%d",&n2);
	
	mult = n1 * n2;
	
	printf("%d",mult);
	
	return 0;
}
