#include <stdio.h>
#include <locale.h>

//Fa�a um algoritmo para ler um n�mero inteiro fornecido pelo usu�rio e exibir
//seu dobro.

int main() {
	setlocale(LC_ALL,"portuguese");
	
	int n1, dobro;
	
	printf("Informe um n�mero inteiro: ");
	scanf("%d",&n1);
	
	dobro = n1 * 2;
	
	printf("%d",dobro);
	
	return 0;
	
}
