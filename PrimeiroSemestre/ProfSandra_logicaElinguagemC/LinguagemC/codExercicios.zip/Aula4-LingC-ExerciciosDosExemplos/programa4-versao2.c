#include <stdio.h>
#include <locale.h>

//Fa�a um algoritmo que leia o pre�o de um par de sapatos numa loja, e escreva
//o pre�o com desconto de X%.

int main() {
	setlocale(LC_ALL,"portuguese");
	
	float preco, desc = 10, valorFinal;
	
	printf("Informe valor do par de sapatos: ");
	scanf("%f",&preco);
	valorFinal = (preco - (preco * desc)/100);
	
	printf("%2.2f com desconto de %2.f%%:",valorFinal,desc);
	
	
	return 0;
}
