#include <stdio.h>
#include <locale.h>
//Escreva um algoritmo que leia tr�s notas de um aluno 
//e a seguir calcule sua m�dia final. 
int main() {
	setlocale(LC_ALL,"portuguese");
	
	printf("\n\n======= M�dia do Aluno =======\n\n");
	
	float n1, n2, n3, media = 0;
	
	printf("Informe primeira nota do aluno(a): ");
	scanf("%f",&n1);
	
	printf("Informe segunda nota do aluno(a): ");
	scanf("%f",&n2);
	
	printf("Informe terceira nota do aluno(a): ");
	scanf("%f",&n3);
	
	media = (n1 + n2 + n3)/3;
	
	printf("M�dia Final %.1f",media);
	
	return 0;
}
