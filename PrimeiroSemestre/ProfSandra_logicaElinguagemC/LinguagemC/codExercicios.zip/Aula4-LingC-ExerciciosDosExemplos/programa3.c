#include <stdio.h>
#include <locale.h>

//Elabore um algoritmo para ler 3 n�meros reais e exibir a soma do primeiro
//n�mero com o segundo, multiplicado pela soma do segundo pelo terceiro

int main() {
	setlocale(LC_ALL,"portuguese");
	
	float n1, n2, n3, resultado;
	
	printf("Informe 3 n�mero reais: ");
	scanf("%f%f%f",&n1,&n2,&n3);

	resultado = (n1+n2) * (n2 + n3);
	
	printf("%.2f",resultado);
	
	
	return 0;
}
