#include <stdio.h>
#include <locale.h>

int main(){
	setlocale(LC_ALL,"portuguese");
	
	char msg[20] = "Ol� mundo";

	printf("%s\n",msg);
	
	
	printf("%c",msg[7]);
		

	return 0;
}

