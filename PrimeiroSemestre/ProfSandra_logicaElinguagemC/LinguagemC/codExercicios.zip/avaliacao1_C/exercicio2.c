#include <stdio.h>
#include <stdlib.h>

int main(){
    char nome[15];
    int apartmento;
    int garagem;

    printf("Digite seu nome: ");
    gets(nome);
    printf("Digite o numero do seu apartamento: ");
    scanf("%d", &apartmento);
    printf("Voce possui garagem? 1 para sim ou 0 para nao: ");
    scanf("%d", &garagem);

    if (garagem == 0) {
        printf("\n %s paga apenas R$ 550,00 de condominio.", nome);
    } else {
        printf("\n %s paga R$ 650,00 de condominio.", nome);
    }

    return 0;
}
