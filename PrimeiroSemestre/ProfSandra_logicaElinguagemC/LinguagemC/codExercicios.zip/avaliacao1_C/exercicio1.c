#include <stdio.h>
#include <stdlib.h>

int main()
{
    float peso, altura, imc;
    char nome[15];

    printf("Digite seu nome:\n");
    gets(nome);
    printf("digite seu peso:\n");
    scanf("%f", &peso);
    printf("Digite sua altura:\n");
    scanf("%f", &altura);

    imc = peso / (altura * altura);

    printf("\n %s com o peso %f e altura %f voce esta ", nome, peso, altura);

    if (imc < 18.5){
        printf("abaixo do peso idea");
    } else {
        if (imc < 24.9){
                printf("saudavel");
        } else {
            if (imc < 29.9){
                printf("com sobrepeso");
            } else {
                if (imc < 34.9){
                    printf("com obesidade grau 1");
                } else {
                    if (imc < 39.9){
                        printf("com obesidade grau 2");
                    } else {
                        printf("com obesidade grau 3");
                    }
                }
            }
        }
    }
    return 0;
}
