#include <stdio.h>
#include <stdbool.h>

int main ()
{
	
 	char string[10];
 	
 	printf ("Digite uma string: ");
 	gets(string);
 
 	printf ("\n\nVoce digitou %s",string);

	bool n = true;  
	printf("\n %d ",n);
	
	if(n==true)
	printf("verdadeiro");
 
 return(0);
} 
