//O programa a seguir ilustra o funcionamento dos operadores l�gicos.
//Compile-o e fa�a testes com v�rios valores para i e j: 

#include <stdio.h> 
#include <locale.h>
int main()
{
	setlocale(LC_ALL,"portuguese");
 	int i, j;
 	printf("informe dois n�meros(cada um sendo 0 ou 1): ");
 	scanf("%d%d", &i, &j);
 	
 	printf("%d AND %d � %d\n", i, j, i && j);
 	printf("%d OR %d � %d\n", i, j, i || j);
 	printf("NOT %d � %d\n", i, !i);
 	
 	return 0;
 	
} 
