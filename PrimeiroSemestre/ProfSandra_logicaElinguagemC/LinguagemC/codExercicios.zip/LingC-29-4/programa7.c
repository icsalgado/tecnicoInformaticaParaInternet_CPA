
#include <stdio.h>
int main() {
 
 int x, y;
 
//pr�-fixados
 x=23;
 
 y = --x;   

printf("\n %d",y);
printf("\n %d",x);

	return 0;
}

