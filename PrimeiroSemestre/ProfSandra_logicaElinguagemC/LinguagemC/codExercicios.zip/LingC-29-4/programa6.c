//Estes operadores podem ser pr�-fixados ou p�s- fixados. A diferen�a � que
//quando s�o pr�-fixados eles incrementam e retornam o valor da vari�vel j�
//incrementada. Quando s�o p�s-fixados eles retornam o valor da vari�vel sem o
//incremento e depois incrementam a vari�vel.
#include <stdio.h>
#include <locale.h>
int main() {
 setlocale(LC_ALL,"portuguese");
 int x, y;
 
//p�s-fixados
 x=23;
 y=x++; 

printf("\n %d",y);
printf("\n %d",x);



	return 0;
}
 
