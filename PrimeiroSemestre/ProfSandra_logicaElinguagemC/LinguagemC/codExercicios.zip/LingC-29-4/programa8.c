#include <stdio.h>
int main() {
	//Diga o resultado das vari�veis x, y e z depois da seguinte sequ�ncia de
	//opera��es: 
 	int x, y ,z;
 	x=y=10;
 	printf("x = %d",x); 
 	
 	z=++x;
 	printf("\n z = %d",z); 
 	
 	x= -x;
 	printf("\n x= %d",x); 
 	
 	y++;
 	printf("\n y = %d",y); 
 	
 	z--;
 	//printf("\n z = %d",z);
 	x=x+y-(z--);
 	printf("\n x = %d",x);
 	
	return 0;
}






