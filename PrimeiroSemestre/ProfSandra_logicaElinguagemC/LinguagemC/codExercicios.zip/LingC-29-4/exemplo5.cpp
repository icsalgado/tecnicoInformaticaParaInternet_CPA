#include <stdio.h>
#include <locale.h>
int main()
{
	setlocale(LC_ALL,"portuguese");
 int x = 1;
 printf("\n %d",x);
 
 //decremento - p�s-incremento
 x--; //equivale x = x - 1
 printf("\n %d ",x);
 
 int y;
 x=23;
 y=x--; 


 printf("\n %d ",y);
 printf("\n %d",x);

 return(0);
}
