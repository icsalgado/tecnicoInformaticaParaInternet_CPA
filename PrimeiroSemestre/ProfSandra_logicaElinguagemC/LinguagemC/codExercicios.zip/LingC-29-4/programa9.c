/* 	Este programa ilustra o funcionamento dos operadores relacionais. 
	Os operadores relacionais retornam verdadeiro (1) ou falso (0).
*/
#include <stdio.h>
#include <locale.h>

int main(){
	setlocale(LC_ALL,"portuguese");
 int i, j;
 
 printf("\nEntre com dois n�meros inteiros: ");
 
 scanf("%d %d", &i, &j);

 printf("\n %d == %d � %d \n", i, j, i==j);  
 printf("\n %d != %d � %d \n", i, j, i!=j);   
 printf("\n %d <= %d � %d \n", i, j, i<=j);
 printf("\n %d >= %d � %d \n", i, j, i>=j);
 printf("\n %d < %d � %d \n", i, j, i<j);
 printf("\n %d > %d � %d \n", i, j, i>j);
 
 return(0);
 
} 
