#include <stdio.h>
int main()
{
 char str[10] = "Joao";
 
 printf("\n\n String: %s",str);
 
 printf("\n Segunda letra: %c", str[1]);
 
 str[1] = 'U';
 
 printf("\nAgora a segunda letra eh: %c", str[1]); 
 printf("\n\nString resultante: %s", str);
 
 return(0);
}
