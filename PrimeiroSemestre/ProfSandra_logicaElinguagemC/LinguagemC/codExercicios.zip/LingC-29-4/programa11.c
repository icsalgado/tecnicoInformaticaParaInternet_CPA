#include <stdio.h> 
#include <locale.h>
int main()
{
	setlocale(LC_ALL,"portuguese");
	
 	int i = 5, j = 7;
 	
	if ( (i >= 3) && ( j <= 7)) 
		printf("%s","true");

		
		
 		//V AND V AND V = V 
 	
 	return 0;
} 
