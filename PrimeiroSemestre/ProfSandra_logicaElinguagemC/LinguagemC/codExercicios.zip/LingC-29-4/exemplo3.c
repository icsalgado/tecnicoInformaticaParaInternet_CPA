#include <stdio.h>
int main()
{
 int a = 17, b = 3;
 int x, y;
 float z = 17., z1, z2;
 x = a / b;
 y = a % b;
 z1 = z / b;
 z2 = a/b; 
 
 printf("%d \n",x);
 printf("%d \n",y);
 printf("%f \n",z1);
 printf("%f \n",z2);
 return(0);
}
