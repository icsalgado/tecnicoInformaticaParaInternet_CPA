#include <stdio.h>

int main(){
 
 int x = 1;
 
 printf(" %d ",x); 
 
 //incremento
 x++; //equivalente x = x + 1
 printf(" %d ",x);
 
 int y;
 x=23;
 y = x++; 

 printf(" %d ",y);
 printf(" %d ",x);
 
 return(0);
}
