#include <stdio.h>
#include <locale.h>

int main() {
	setlocale(LC_ALL,"portuguese");
	int n1, n2;
	
	printf("Informe primeiro valor: ");
	scanf("%d",&n1);
	
	printf("Informe segundo valor: ");
	scanf("%d",&n2);

	if(n1 > n2){
		printf("%d � maior que %d",n1,n2);
	} else {
		if(n2 > n1){
			printf("n2 = %d � maior que n1 = %d",n2,n1);	
		} else {
			printf("Os valores s�o iguais ");
		}
		
	}
	
	return 0;
}
