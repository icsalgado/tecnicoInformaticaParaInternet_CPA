#include <stdio.h>
#include <locale.h>

int main() {
	setlocale(LC_ALL,"portuguese");
	
	int n1, n2, n3, acumulador;
	printf("Informe 3 valores inteiros: ");
	scanf("%d%d%d",&n1,&n2,&n3);
	
	if(n1>=n2 && n1>=n3){
		acumulador = n1;
	} else {
		if (n2>=n1 && n2>=n3) {
			acumulador = n2;
		} else{
			acumulador = n3;
		}
	}
	
	printf("O maior n�mero � %d ",acumulador);
	return 0;
}
