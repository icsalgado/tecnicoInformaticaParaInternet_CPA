#include <stdio.h>
#include <locale.h>

int main() {
	setlocale(LC_ALL,"portuguese");
	float n1, n2, media = 0;
	printf("Informe as notas de 0 a 10: ");
    printf("\nDigite a primeira nota: ");
    scanf("%f",&n1);
    printf("\nDigite a segunda nota: ");
    scanf("%f",&n2);
    media = (n1 + n2)/2;
    printf("\nM�dia = %2.1f ",media);
    if(media >= 7.0){
    	printf("\nAprovado");
	} else {
		if(media >= 5.0 && media < 7.0){
			printf("\nExame");
		} else {
			printf("\nReprovado");	
		}
	}
    
	return 0;
}
