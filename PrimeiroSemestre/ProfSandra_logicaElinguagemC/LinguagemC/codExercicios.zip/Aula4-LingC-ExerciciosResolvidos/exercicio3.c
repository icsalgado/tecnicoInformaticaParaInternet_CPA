#include <stdio.h>
#include <locale.h>

int main() 
{
	setlocale(LC_ALL,"portuguese");
	float custoFab, dist, impostos, custoCon,j;
	
	printf("Informe o custo de f�brica: R$");
	scanf("%f",&custoFab);

	dist=((12.0f/100.0f)*custoFab);
	impostos=(45.0f/100.0f)*custoFab;
	custoCon=custoFab+dist+impostos;
	printf("Custo ao consumidor ser� de R$%2.2f",custoCon);
	
	return 0;
}
