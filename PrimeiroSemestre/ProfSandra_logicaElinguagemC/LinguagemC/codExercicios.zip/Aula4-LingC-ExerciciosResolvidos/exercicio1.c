#include <stdio.h>
#include <locale.h>


int main() {
	setlocale(LC_ALL,"portuguese");
	
	float n1, n2, m = 0;
	
	printf("Informe a primeira valor: ");
	scanf("%f",&n1);
	printf("Informe segundo valor: ");
	scanf("%f",&n2);
	m = (n1 + n2)/2;
	printf("M�dia = %2.1f ",m);
	
	
	//printf("A m�dia dos n�meros %f e %f �: %2.1f",n1,n2,m);
	return 0;
}



