#include <stdio.h>
#include <stdlib.h>
#include<locale.h>
#include <math.h>

#define PI 3.14 

int main() 
{
	setlocale(LC_ALL,"portuguese");
	float r,a;
	
	printf("Informe o raio:");
	scanf("%f",&r);
	a= PI * pow(r,2);
	printf("A �rea do c�rculo �:%.2f",a);
	return 0;
}
