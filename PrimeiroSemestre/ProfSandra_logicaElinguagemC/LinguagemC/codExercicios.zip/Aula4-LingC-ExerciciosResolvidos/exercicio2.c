#include <stdio.h>
#include <locale.h>


int main() {
	setlocale(LC_ALL,"portuguese");
	float cm, dist, vol;
	printf("Informe a dist�ncia total percorrida: ");
 	scanf("%f",&dist);
 	printf("volume de combust�vel consumido para percorr�-lo: ");
 	scanf("%f",&vol);
 	cm = dist / vol;
 	printf("Consumo m�dio do autom�vel (medido em Km/l) foi: %.1f",cm);
	
	return 0;
}
