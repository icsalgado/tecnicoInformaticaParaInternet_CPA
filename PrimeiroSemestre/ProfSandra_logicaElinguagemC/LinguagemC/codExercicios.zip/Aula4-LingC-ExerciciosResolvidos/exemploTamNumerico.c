#include <stdio.h>
#include <conio.h>

void main()
{
   float Numero;
   
   Numero = -2.5;
   //clrscr();
   
   printf("1234567890\n");
   
   printf("%7f\n", Numero);
   
   printf("%7.0f\n", Numero);
   
   printf("%7.3f\n", Numero);
   
   printf("%8.3f\n", Numero);
   printf("%9.3f\n", Numero);
   printf("\n");
   printf("%8.4f\n", Numero);
   printf("%8.1f\n", Numero);
   printf("%6.12f\n", Numero);
	
   getch();
}

// Resultados

