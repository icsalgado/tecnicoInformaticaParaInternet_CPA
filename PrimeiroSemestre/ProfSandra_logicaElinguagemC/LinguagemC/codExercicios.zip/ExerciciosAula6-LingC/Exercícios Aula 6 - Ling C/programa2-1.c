#include <stdio.h>
#include <stdlib.h>
#include<locale.h>

int main(int argc, char *argv[]) 
{
	setlocale(LC_ALL,"portuguese");
	
	float n1, n2, n3 ,media = 0;
	
	char resultado[15] ="Reprovado";
	
	
	printf("Insira primeira nota: ");
	scanf("%f",&n1);
	printf("Insira segunda nota: ");
	scanf("%f",&n2);
	printf("Insira terceira nota: ");
	scanf("%f",&n3);
	
	media=  (n1+n2+n3)/3;
	
	if (media >= 7){
		strcpy(resultado, "Aprovado");
	}
		
	printf("A m�dia �: %.2f - %s!",media,resultado);
	
	return 0;
}
