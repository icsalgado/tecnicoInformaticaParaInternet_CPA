#include <stdio.h>
#include<locale.h>
int main() {
	setlocale(LC_ALL,"portuguese");
	
	float n1, n2, resultado = 0;

	printf("Informe dois valores reais: ");
	scanf("%f%f",&n1,&n2);

	resultado = n1+n2;
	
	printf("A soma de %2.2f + %2.2f = %2.2f \n",n1,n2,resultado);
	
	if(resultado >= 10.0){
		resultado = resultado + 5;
	} 
	else
	{
		resultado = resultado - 7;
	}
		
		printf("\nA soma total �:%.2f ",resultado);

	return 0;
}
