#include <stdio.h>
#include <stdlib.h>
#include<locale.h>

int main() 
{
	setlocale(LC_ALL,"portuguese");
	
	int n1, r = 0;
	
	printf("Digite um n�mero inteiro: ");
	scanf("%i",&n1);
	
	r = n1%2;
	
	printf("Resto da divis�o = %d \n",r);
	
	if(n1 % 2 == 0){
		printf("PAR");
	}
	else
	{
		printf("�MPAR");
	}
		

	return 0;
}
