#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

int main() {
	setlocale(LC_ALL,"portuguese");		
	
	float n1, n2, n3, media = 0;
	
	printf("======= C�lculo da m�dia =======\n");
	
	printf("Informe primeiro nota: ");
	scanf("%f",&n1); 
	
	printf("Informe o segundo nota: ");
	scanf("%f",&n2);
	
	printf("Informe o terceira nota: ");
	scanf("%f",&n3);
	
	media = (n1 + n2 + n3)/3;
	
	printf("M�dia do aluno = %2.1f \n ",media);
	
	if(media >= 7.0){
		printf("Aprovado");
	} else {
		printf("Reprovado");	
	}
				
	return 0;
}
