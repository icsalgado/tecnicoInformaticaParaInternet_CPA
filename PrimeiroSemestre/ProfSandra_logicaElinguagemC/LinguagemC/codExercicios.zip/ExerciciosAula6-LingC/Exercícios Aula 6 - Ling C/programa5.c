#include <stdio.h>
#include <stdlib.h>
#include<locale.h>
int main() {
	setlocale(LC_ALL,"portuguese");
	float valor, saldo = 2000;
	
	printf("Quantos deseja sacar? R$ ");
	scanf("%f",&valor);
	fflush(stdin);
	
	if(valor < saldo){
		saldo = saldo - valor;
		printf("Valor do saque � de R$ %2.2f ",valor);
	}
	else
	{
		printf("\n Valor do saque est� acima do saldo dispon�vel! ");
	}
	
	printf("\n Saldo disponivel R$ %2.2f",saldo);
	
	return 0;
}
