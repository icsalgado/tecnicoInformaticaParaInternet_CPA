#include <stdio.h>
#include<locale.h>
int main() {
	setlocale(LC_ALL,"portuguese");
	
	
	float saque, saldo = 2000.0;
	
	printf ("\n\n digite o valor do saque: ");
	scanf("%f",&saque);
	fflush(stdin);
	
	
	printf ("O saldo da conta � de %2.2f \n",saldo);
	
	
	if(saque >= saldo){
		
	    printf("SALDO INDISPONIVEL\n");
	
	}
	else {
	   	saldo = saldo - saque;
	    printf("saque realizado no valor de %2.2f \n",saque);
	}
		
	printf("Saldo dispon�vel R$ %2.2f ",saldo);
	return 0;
}
