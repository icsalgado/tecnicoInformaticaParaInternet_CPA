#include <stdio.h>
#include<locale.h>

int main() {
	setlocale(LC_ALL,"portuguese");
	
	float n;
	
	printf("Digite um n�mero inteiro: ");
	scanf("%f",&n);
	
	if (n <= 50) {
		n = 0;
	}
	
	printf("Valor de n: %2.0f ",n);
	
	return 0;
}
