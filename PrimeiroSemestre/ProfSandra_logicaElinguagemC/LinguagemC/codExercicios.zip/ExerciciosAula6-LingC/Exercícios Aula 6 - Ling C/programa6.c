#include <stdio.h>
#include<locale.h>

int main() {
	setlocale(LC_ALL,"portuguese");
	
	int n, i=0, p=0, r = 0;
	
	printf("Digite um n�mero inteiro: ");
	scanf("%d",&n);
	r = n % 2;
	if(r == 0){
		p = n;
	} else {
		i = n;
	}
	
	printf("Par: %d ",p);
	printf("\n�mpar: %d ",i);
	
	return 0;
}
