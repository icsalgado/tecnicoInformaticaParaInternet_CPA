#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

int main() {
	setlocale(LC_ALL,"portuguese");		
	
	float n1, n2, soma = 0;
	
	printf("======= Soma de dois valores reais =======\n");
	
	printf("Informe primeiro valor: ");
	scanf("%f",&n1); 
	
	printf("Informe o segundo valor: ");
	scanf("%f",&n2);
	
	soma = n1 + n2;
	
	if(soma > 10.0){
		printf("Resultado da soma = %2.2f",soma);
	}
				
	return 0;
}
