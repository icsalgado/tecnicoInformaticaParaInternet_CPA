#include <stdio.h>
#include<locale.h>

int main() {
	setlocale(LC_ALL,"portuguese");
	
	int n, a = 0, b = 0;
	
	printf("Digite um n�mero inteiro: ");
  	scanf("%d",&n);
  	
  	if (n > 0) {
  		a = n;
	} else {
		b = n;
	}
	
	printf("Valor de n: %d",n);
  	printf("\nValor de a: %d",a);
  	printf("\nvalor de b: %d",b);
  	
	return 0;
}
